# Security — TREK Guest Portal v1.0.2

## Security goals

Guest Portal is intentionally treated as an internet-facing read-only presentation layer. It should expose only information already authorized by native TREK/Journey public-share links while keeping infrastructure credentials, plugin databases and authenticated TREK data unavailable to guest browsers.

## Trust boundaries

- **TREK** remains authoritative for whether a trip/Journey is publicly shared.
- **Guest Portal companion** validates native public-share tokens and creates short-lived guest sessions.
- **Browser** receives only a random session cookie after initial validation; native bearer tokens are removed from the visible URL/history entry.
- **Immich API key** and **AeroDataBox key** remain server-side mounted secrets.
- **Guest Portal cache** is separate from TREK/Flight Tracker databases.

## Hardened design decisions

### Token-free API URLs

Native share tokens are accepted only by `POST /api/session` in a JSON body. The response sets a random `HttpOnly; Secure; SameSite=Strict` cookie. All later endpoints derive authorization from the server-side session.

### No plugin database mounted at runtime

The recommended v1.0.2 container does not mount TREK's `plugins-data` directory or the Flight Tracker database. The bundled one-shot extractor is run manually with read-only plugin-data access and writes only the AeroDataBox key to a dedicated secret file before the public container starts.

### Minimal public diagnostics

`/health` returns only `ok` and version. Detailed provider/cache state is available in container logs.

### Secrets

Use:

```text
/run/secrets/aerodatabox_api_key
/run/secrets/immich_api_key
```

Secret values are not intentionally logged or returned to the browser.

### Container isolation

Recommended Compose settings use an unprivileged UID/GID, read-only root filesystem, all capabilities dropped, `no-new-privileges`, memory/PID limits and a hardened tmpfs.

## Remaining limitations

- Native TREK/Journey share URLs are bearer capabilities. Anyone who obtains an owner-generated share link can establish a guest session until the native share is revoked/rotated.
- Guest sessions are stored in memory and are lost on companion restart. The guest must reopen the original owner-generated share link afterward.
- The Mapbox `pk...` token is a browser/public token by design; use a dedicated token with URL restrictions and minimum required scopes.
- Third-party providers (Mapbox, AeroDataBox, adsb.fi, Immich when remote) receive the network requests necessary to provide enabled functionality.
- This project is custom integration code, not an official TREK component. Re-test compatibility before moving to a new TREK major version.

## Migration warning from 0.3.x

Older 0.3.x builds used native share tokens in some API request URLs. If Apache `combined` access logging was enabled, historical logs may contain those old bearer tokens. After v1.0.2 is verified, rotate both native TREK and Journey shares and handle old logs according to your retention/security policy.

## Reporting / response

If you discover a suspected exposure:

1. disable or rotate the affected native TREK/Journey share;
2. stop the Guest Portal companion if active exploitation is suspected;
3. preserve relevant logs for investigation while controlling access to them;
4. rotate provider API keys if they may have been exposed;
5. patch/redeploy before creating replacement public links.
