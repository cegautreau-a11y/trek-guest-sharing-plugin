# TREK Guest Portal v1.0.2

**Security-hardened guest sharing for TREK 3.4.x**

Guest Portal provides a polished, mobile-friendly public trip experience with four guest-facing sections:

- **Plan** — interactive Mapbox itinerary; selecting a stop moves the map below that stop and frames a 1 km radius on desktop and mobile.
- **Flights** — transport cards plus live AeroDataBox/adsb.fi flight information, persistent caching, BASIC-tier rate limiting and a visible next-refresh countdown.
- **Reservations** — accommodations and non-transport bookings only.
- **Photos** — Journey/Immich photos ordered chronologically and grouped by original Immich capture date when available.

This release is a security-focused redesign of the 0.3.x series. It consists of two parts:

1. `trek-guest-portal-1.0.2.zip` — upload through **TREK → Admin → Plugins**.
2. `trek-guest-portal-companion-1.0.2-portainer.zip` — the public companion container behind your existing Apache reverse proxy.

---

## Security model in v1.0.2

### Native share tokens are no longer used in API URLs

The owner-generated URL still carries the TREK/Journey public-share tokens in the URL fragment:

```text
https://trax.wherearemypacketsgoing.com/guest-portal/#trip=...&journey=...&title=Brazil+Trip
```

A URL fragment is not sent in the initial HTTP request. On first load the browser sends the tokens once, inside the JSON body of:

```text
POST /guest-portal/api/session
```

The companion validates them with TREK and returns a random cookie with:

```text
HttpOnly
Secure
SameSite=Strict
Path=/guest-portal/
```

After the session is created, the browser removes the bearer tokens from the visible URL/history entry. Subsequent requests are token-free:

```text
GET /guest-portal/api/trip
GET /guest-portal/api/journey
GET /guest-portal/api/flights/42
GET /guest-portal/api/photo-dates
GET /guest-portal/api/photos/7/thumbnail
GET /guest-portal/api/photos/7/original
```

This prevents normal Apache `combined` access logs from recording the native TREK/Journey bearer tokens in request URLs.

### The companion does not mount TREK plugin data at runtime

The 0.3.x companion mounted TREK's plugin-data tree read-only to reuse Flight Tracker. v1.0.2 removes that runtime access entirely.

A bundled **one-shot helper** scans plugin data only while you deliberately run it, extracts the existing Flight Tracker AeroDataBox key to a dedicated secret file, and exits. The long-running public container never receives access to the Flight Tracker database or any other plugin database.

### Secrets stay server-side

The recommended deployment uses mounted files:

```text
/run/secrets/aerodatabox_api_key
/run/secrets/immich_api_key
```

Neither secret is put in `config.js`, returned by `/health`, exposed to browser JavaScript, or written to normal companion logs.

### Additional hardening

v1.0.2 also includes:

- exact HTTPS `PUBLIC_ORIGIN` validation;
- same-origin validation for session creation/logout;
- bounded, rate-limited in-memory guest sessions;
- minimal public `/health` output;
- generic public errors while detailed errors remain in container logs;
- Content Security Policy for Guest Portal/Mapbox resources;
- `Referrer-Policy: strict-origin-when-cross-origin` so a URL-restricted Mapbox public token can work;
- HSTS, `nosniff`, COOP/CORP, Permissions-Policy and `frame-ancestors 'none'`;
- static path traversal protection;
- parameterized SQLite queries;
- read-only container root filesystem;
- non-root UID/GID `65532:65532` by default;
- all Linux capabilities dropped;
- `no-new-privileges`;
- PID/memory limits and `noexec,nosuid,nodev` tmpfs;
- Guest Portal cache directory mode `0700` and database mode `0600` where supported;
- Admin-plugin iframe messaging pinned to TREK's established parent origin rather than `postMessage(..., '*')`.

See `SECURITY.md` for the threat model and remaining limitations.

---

# Upgrade from 0.3.x

v1.0.2 is a **breaking security upgrade**. Install both the Admin plugin and companion.

## 1. Back up current Guest Portal files

```bash
cp -a /datastore/trax-guest /datastore/trax-guest.backup-before-1.0.2
```

Do not delete your existing:

```text
/datastore/trax-guest/public/config.js
```

It contains your Mapbox public token. The update ZIP intentionally includes `config.js.example`, not `config.js`.

## 2. Upload the v1.0.2 TREK plugin

Upload:

```text
trek-guest-portal-1.0.2.zip
```

through:

**TREK → Admin → Plugins → Upload**

Enable/update **Guest Portal** after reviewing its permissions:

```text
db:own
db:read:trips
```

## 3. Extract the v1.0.2 companion

Extract:

```text
trek-guest-portal-companion-1.0.2-portainer.zip
```

over:

```text
/datastore/trax-guest/
```

Expected layout:

```text
/datastore/trax-guest/
├── public/
│   ├── index.html
│   ├── app.js
│   ├── style.css
│   ├── config.js              # existing local file; preserve it
│   └── config.js.example
├── server/
│   └── server.py
├── tools/
│   ├── extract-flight-tracker-key.py
│   └── find-flight-tracker-db.py
├── cache/
├── secrets/
├── docker-compose.yml
├── README.md
└── SECURITY.md
```

---

# Configure secrets and storage

## 4. Create hardened directories

```bash
mkdir -p /datastore/trax-guest/cache /datastore/trax-guest/secrets
chown 65532:65532 /datastore/trax-guest/cache /datastore/trax-guest/secrets
chmod 700 /datastore/trax-guest/cache /datastore/trax-guest/secrets
```

## 5. Extract the existing Flight Tracker AeroDataBox key

You do **not** need to find or display the key manually.

Run the bundled one-shot extractor:

```bash
docker run --rm \
  -v /datastore/trax/data/plugins-data:/scan:ro \
  -v /datastore/trax-guest/tools:/tools:ro \
  -v /datastore/trax-guest/secrets:/out \
  python:3.12-alpine \
  python /tools/extract-flight-tracker-key.py /scan /out/aerodatabox_api_key
```

The helper scans TREK plugin data only during this command. It does **not print the key**. It writes:

```text
/datastore/trax-guest/secrets/aerodatabox_api_key
```

Then set ownership/permissions:

```bash
chown 65532:65532 /datastore/trax-guest/secrets/aerodatabox_api_key
chmod 600 /datastore/trax-guest/secrets/aerodatabox_api_key
```

Verify the file exists without printing its contents:

```bash
stat /datastore/trax-guest/secrets/aerodatabox_api_key
```

If the helper reports more than one candidate, it refuses to guess. Use `tools/find-flight-tracker-db.py` to identify the intended database and resolve the duplicate before proceeding.

## 6. Create the Immich API-key secret

Create a dedicated Immich API key with only the asset-read permissions needed by Guest Portal, then write it to a file without placing it in Portainer's environment editor:

```bash
umask 077
read -rsp "Immich API key: " IMMICH_KEY; echo
printf '%s' "$IMMICH_KEY" > /datastore/trax-guest/secrets/immich_api_key
unset IMMICH_KEY
chown 65532:65532 /datastore/trax-guest/secrets/immich_api_key
chmod 600 /datastore/trax-guest/secrets/immich_api_key
```

---

# Portainer / Docker Compose

Use this service in the same Compose/Portainer stack as TREK's `app` service:

```yaml
  trek-guest-portal:
    image: python:3.12-alpine
    container_name: trek-guest-portal
    restart: unless-stopped
    read_only: true
    user: "65532:65532"

    # Bind only to the TREK host interface reached by Apache.
    ports:
      - "10.110.5.2:8088:8080"

    environment:
      - LISTEN_PORT=8080
      - TREK_HOST=app
      - TREK_PORT=3000
      - PUBLIC_ROOT=/srv/public
      - PUBLIC_ORIGIN=https://trax.wherearemypacketsgoing.com
      - COOKIE_PATH=/guest-portal/
      - SESSION_TTL_SECONDS=43200
      - SESSION_MAX=2048
      - SESSION_CREATE_PER_MINUTE=120
      - LOG_LEVEL=INFO

      - AERODATABOX_API_KEY_FILE=/run/secrets/aerodatabox_api_key
      - AERODATABOX_TIMEOUT=10
      - AERODATABOX_MIN_INTERVAL=1.6
      - AERODATABOX_429_RETRIES=2
      - AERODATABOX_429_BACKOFF=2.5

      - GUEST_CACHE_DB=/cache/guest-portal.db
      - GUEST_CACHE_MAX_ROWS=512

      - IMMICH_URL=https://YOUR-IMMICH-HOST
      - IMMICH_API_KEY_FILE=/run/secrets/immich_api_key
      - IMMICH_VERIFY_TLS=true
      - IMMICH_TIMEOUT=15
      - IMMICH_DATE_CACHE_TTL=86400

    volumes:
      - type: bind
        source: /datastore/trax-guest/public
        target: /srv/public
        read_only: true
        bind:
          create_host_path: false
      - type: bind
        source: /datastore/trax-guest/server
        target: /srv/server
        read_only: true
        bind:
          create_host_path: false
      - type: bind
        source: /datastore/trax-guest/cache
        target: /cache
        bind:
          create_host_path: false
      - type: bind
        source: /datastore/trax-guest/secrets/immich_api_key
        target: /run/secrets/immich_api_key
        read_only: true
        bind:
          create_host_path: false
      - type: bind
        source: /datastore/trax-guest/secrets/aerodatabox_api_key
        target: /run/secrets/aerodatabox_api_key
        read_only: true
        bind:
          create_host_path: false

    command: ["python", "/srv/server/server.py"]

    tmpfs:
      - /tmp:noexec,nosuid,nodev,size=16m

    security_opt:
      - no-new-privileges:true

    cap_drop:
      - ALL

    pids_limit: 128
    mem_limit: 256m
```

The companion needs Docker-network access to TREK at `app:3000`, but it does not need the TREK database, uploads directory, plugin directory or plugin-data directory.

The long bind syntax uses `create_host_path: false` so a missing secret file fails deployment clearly instead of being silently created as a directory. This prevents the file-vs-directory mount failure that short bind syntax can cause.

### Optional environment override

`AERODATABOX_API_KEY` and `IMMICH_API_KEY` remain supported for compatibility, but mounted secret files are preferred. If the corresponding `*_FILE` variable is set, use a valid readable secret file.

---

# Apache reverse proxy

Keep Guest Portal before your final `/` catch-all rule:

```apache
# Guest Portal companion — must be before ProxyPass "/"
ProxyPass        "/guest-portal/" "http://10.110.5.2:8088/" connectiontimeout=5 timeout=300 retry=0
ProxyPassReverse "/guest-portal/" "http://10.110.5.2:8088/"
RedirectMatch 302 ^/guest-portal$ /guest-portal/

# Main TREK catch-all — last
ProxyPass        "/" "http://10.110.5.2:3300/" connectiontimeout=5 timeout=300 retry=0
ProxyPassReverse "/" "http://10.110.5.2:3300/"
```

Your existing WebSocket `/ws` and MCP `/mcp` rules remain before these rules.

Because port `8088` is bound specifically to `10.110.5.2`, also restrict TCP/8088 at the host/network firewall so only the Apache reverse-proxy host can connect to it.

---

# Mapbox

Preserve/create:

```text
/datastore/trax-guest/public/config.js
```

Example:

```javascript
window.GUEST_PORTAL_CONFIG = {
  mapboxAccessToken: 'pk.YOUR_PUBLIC_MAPBOX_TOKEN',
  mapboxStyle: 'mapbox://styles/mapbox/standard',
  mapbox3d: true,
  mapboxHighQuality: false
};
```

Use a **dedicated public Mapbox token** for Guest Portal and restrict it to:

```text
https://trax.wherearemypacketsgoing.com/*
```

v1.0.2 uses `Referrer-Policy: strict-origin-when-cross-origin`, allowing Mapbox URL restrictions to receive the site origin while avoiding full-path referrers on cross-origin requests.

The Plan tab keeps the current Guest Portal behavior:

- Mapbox Standard by default;
- Mapbox marker/route styling modeled on the editable TREK planner;
- map displayed directly under the selected itinerary item;
- selected stop centered in a fixed **1 km geographic radius** on desktop and mobile;
- 1 km framing re-applied after mobile viewport/orientation changes.

---

# Start and verify

Redeploy the stack, then watch startup:

```bash
docker logs --tail 100 -f trek-guest-portal
```

Public health is intentionally minimal:

```bash
curl -s http://10.110.5.2:8088/health
```

Expected:

```json
{"ok":true,"version":"1.0.2"}
```

Detailed integration state appears only in the container log, not `/health`.

## Verify security headers

```bash
curl -I https://trax.wherearemypacketsgoing.com/guest-portal/
```

Confirm headers such as:

```text
Content-Security-Policy: ...
Referrer-Policy: strict-origin-when-cross-origin
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Strict-Transport-Security: max-age=31536000
```

## Verify token-free access logs

Open a normal Guest Portal owner-generated link. After it loads, the address bar should no longer contain `#trip=` or `#journey=`.

Then inspect Apache requests:

```bash
grep 'guest-portal' /var/log/apache2/trek-access.log | tail -50
```

You should see routes such as:

```text
POST /guest-portal/api/session
GET /guest-portal/api/trip
GET /guest-portal/api/journey
GET /guest-portal/api/flights/...
GET /guest-portal/api/photo-dates
```

You should **not** see the native share-token values in API request URLs.

---

# Guest sessions

Default session lifetime:

```text
12 hours
```

Sessions are held only in companion memory and are bounded by `SESSION_MAX`.

A companion restart or session expiry invalidates existing guest cookies. Because v1.0.2 removes bearer tokens from the current browser URL after establishing a session, the guest must reopen the **original owner-generated Guest Portal link** to establish a new session after expiry/restart.

This is intentional: the browser does not retain long-lived bearer tokens once the session is established.

---

# Flights

Flights and Reservations are always visible tabs, even when empty.

Guest Portal uses:

- AeroDataBox for current flight schedule/status details;
- adsb.fi for live aircraft information when available;
- Guest Portal's own persistent SQLite cache for successful live refreshes.

The Flight Tracker plugin database is **not mounted into the running v1.0.2 companion**.

## Refresh cadence

The server/browser schedule is based on time to departure/status:

| Flight state | Target refresh interval |
|---|---:|
| More than 48 hours away | 2 hours |
| 12–48 hours | 30 minutes |
| 3–12 hours | 5 minutes |
| Less than 3 hours | 1 minute |
| Boarding / departed / en route / approaching / diverted | 1 minute |
| Unknown departure time | 5 minutes |
| Completed/past | no continuous refresh |

The Flights page shows a live **Next auto refresh** countdown.

## BASIC-tier protection

AeroDataBox calls are serialized through a global companion limiter. The default minimum spacing is:

```text
1.6 seconds
```

HTTP 429 responses use backoff/retry. The persistent cache is shared by all guest viewers, so multiple viewers do not each trigger independent refreshes for the same flight.

## Persistent flight cache

Stored at:

```text
/datastore/trax-guest/cache/guest-portal.db
```

The cache survives container restarts, Portainer redeploys and Docker-host reboots. It is Guest Portal-owned; Guest Portal never writes to another plugin's database.

---

# Photos / Immich

Guest Portal receives the shared Journey photo IDs from TREK, validates them through the Journey share, then asks Immich server-side for the original asset metadata using the Immich asset ID.

Date priority:

1. Immich EXIF `dateTimeOriginal`;
2. Immich `localDateTime`;
3. Immich `fileCreatedAt`;
4. Journey entry/photo timestamp;
5. `Undated` only if none can be resolved.

Resolved dates are cached server-side. The Immich API key never reaches the browser.

Journal content is not displayed.

---

# Reservations

Reservations contains:

- accommodations;
- non-transport booking details.

Transportation is excluded from Reservations and is kept under Flights.

---

# Logging

View logs in Portainer or:

```bash
docker logs -f trek-guest-portal
```

Default:

```yaml
- LOG_LEVEL=INFO
```

Temporary deeper diagnostics:

```yaml
- LOG_LEVEL=DEBUG
```

The companion logs startup, session lifecycle, upstream validation failures, Immich lookups, flight refresh/cache activity, AeroDataBox rate limiting and exceptions.

It does **not** log:

- Immich API keys;
- AeroDataBox API keys;
- full TREK/Journey share tokens;
- guest session IDs in full.

Identifiers are reduced to short fingerprints when correlation is useful.

---

# Migrating safely from 0.3.x

The older 0.3.x design placed native TREK/Journey tokens into some later guest API URLs. With Apache `combined` logging, historical access logs may therefore contain replayable old share tokens.

After v1.0.2 is working:

1. Regenerate/rotate the native TREK public trip share link.
2. Regenerate/rotate the Journey public share link.
3. Save the new links in the Guest Portal plugin.
4. Verify the new Guest Portal link works.
5. Archive/purge old Apache logs according to your normal retention/security policy.

Rotating the native links invalidates old bearer tokens that may exist in historical logs.

---

# Troubleshooting

## `Guest session required`

The cookie expired or the companion restarted. Reopen the original owner-generated Guest Portal URL containing `#trip=...` to create a new session.

## `Session origin rejected`

Verify:

```yaml
- PUBLIC_ORIGIN=https://trax.wherearemypacketsgoing.com
```

Do not include a trailing path such as `/guest-portal/` in `PUBLIC_ORIGIN`.

## Mapbox says no public token

Verify the host file:

```bash
cat /datastore/trax-guest/public/config.js
```

and the served file:

```bash
curl -s https://trax.wherearemypacketsgoing.com/guest-portal/config.js
```

The property must be exactly:

```javascript
mapboxAccessToken: 'pk....'
```

## AeroDataBox is not configured

Verify secret file existence without displaying it:

```bash
stat /datastore/trax-guest/secrets/aerodatabox_api_key
```

Then verify ownership:

```bash
chown 65532:65532 /datastore/trax-guest/secrets/aerodatabox_api_key
chmod 600 /datastore/trax-guest/secrets/aerodatabox_api_key
```

Re-run the one-shot extractor if necessary.

## Immich dates are missing

Verify:

```bash
stat /datastore/trax-guest/secrets/immich_api_key
docker logs trek-guest-portal | grep -i immich
```

Ensure `IMMICH_URL` is the Immich base URL and the dedicated key can read asset metadata.

## Persistent cache is disabled

```bash
ls -ld /datastore/trax-guest/cache
chown 65532:65532 /datastore/trax-guest/cache
chmod 700 /datastore/trax-guest/cache
```

Restart and inspect the container log.

## Apache returns 503

From the Apache host:

```bash
curl -I http://10.110.5.2:8088/
```

From the Docker host:

```bash
curl -I http://127.0.0.1:8088/
```

If localhost fails, inspect:

```bash
docker logs trek-guest-portal
```

If localhost works but Apache cannot reach `10.110.5.2:8088`, check the Docker port binding and host firewall.

---

# Backup / upgrade notes

Back up:

```text
/datastore/trax-guest/public/config.js
/datastore/trax-guest/cache/
/datastore/trax-guest/secrets/
```

Do not put secret files in source control or share them with the Admin-plugin ZIP.

Normal companion upgrades replace `public/app.js`, `public/index.html`, `public/style.css` and `server/server.py`. The supplied update packages intentionally avoid overwriting your real `public/config.js`.

The Admin plugin and companion should be kept on the same major release when possible.

---

# Version

```text
Guest Portal plugin:     1.0.2
Guest Portal companion:  1.0.2
TREK compatibility:      >=3.4.0 <4.0.0
```
